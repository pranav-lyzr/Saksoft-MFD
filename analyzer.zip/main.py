from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel, HttpUrl
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId
from git import Repo
import tempfile
import shutil
from typing import Dict, Any
import json
import httpx
import time
import requests
from analyzer.core import RepositoryAnalyzer
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI()


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development only
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# MongoDB Connection
MONGO_URI = "mongodb://root:example@mongo:27017"
client = AsyncIOMotorClient(MONGO_URI)
db = client["mydatabase"]
analyzer = RepositoryAnalyzer()


LYZR_RAG_API_URL = "https://rag-prod.studio.lyzr.ai/v3/rag"
LYZR_AGENT_API_URL = "https://agent-prod.studio.lyzr.ai/v3/agent"
LYZR_API_URL = "https://agent-prod.studio.lyzr.ai/v3/inference/chat/"
API_KEY = "sk-default-yStV4gbpjadbQSw4i7QhoOLRwAs5dEcl"
USER_ID = "pranav@lyzr.ai"

class ProjectCreate(BaseModel):
    name: str

class GitHubLink(BaseModel):
    github_url: HttpUrl

class CodeQuery(BaseModel):
    message: str

class AgentQuery(BaseModel):
    message: str
    project_id: str

# 1️⃣ Create Project
@app.post("/create_project")
async def create_project(project: ProjectCreate):
    project_collection = db.projects
    new_project = {
        "name": project.name,
        "github_links": [],
        "analysis_results": {}
    }
    result = await project_collection.insert_one(new_project)
    return {"project_id": str(result.inserted_id), "message": "Project created successfully"}



# 2️⃣ Add GitHub Link with RAG Analysis
@app.post("/project/{project_id}/repo")
async def add_github_link(project_id: str, link: GitHubLink):
    try:
        obj_id = ObjectId(project_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid project ID format")

    project = await db.projects.find_one({"_id": obj_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    github_url_str = str(link.github_url)

    await db.projects.update_one(
        {"_id": obj_id},
        {"$push": {"github_links": github_url_str}}
    )

    # Ensure direct execution instead of background task
    await analyze_repository_background(obj_id, github_url_str)

    return {"message": "GitHub link added successfully. Analysis completed."}

async def analyze_repository_background(project_id: ObjectId, repo_url: str):
    temp_dir = tempfile.mkdtemp()
    try:
        # Create out directory if it doesn't exist
        out_dir = os.path.join(os.getcwd(), "out")
        os.makedirs(out_dir, exist_ok=True)

        # Fetch project data first to check for existing analysis
        project = await db.projects.find_one({"_id": project_id})
        if not project:
            raise Exception("Project not found")

        # Only analyze if no existing results
        if not project.get("analysis_results"):
            # Clone and analyze repository
            Repo.clone_from(repo_url, temp_dir)
            analysis_result = analyzer.analyze_repository(temp_dir)
            result_dict = json.loads(json.dumps(analysis_result, default=str))
            
            # Update project with new analysis results
            await db.projects.update_one(
                {"_id": project_id},
                {"$set": {"analysis_results": result_dict}}
            )
        else:
            # Use existing analysis results
            result_dict = project["analysis_results"]

        project_name = project["name"]
        
        # Save analysis results to out folder (optional: add timestamp to prevent overwrite)
        output_file = os.path.join(out_dir, f"{project_name}_analysis.json")
        if not os.path.exists(output_file):  # Prevent file overwrite
            with open(output_file, "w") as f:
                json.dump(result_dict, f, indent=2)

        # Only create RAG and agents if they don't exist
        if not project.get("rag_id"):
            rag_id = create_rag_collection()
            if not rag_id:
                raise Exception("Failed to create RAG collection")
            
            train_rag(rag_id, result_dict)
            
            # Create agents
            search_agent = create_agent(rag_id, "search", SEARCH_INSTRUCTIONS, project_name)
            generate_agent = create_agent(rag_id, "generate", GENERATE_INSTRUCTIONS, project_name)

            # Update project with new IDs
            update_data = {
                "rag_id": rag_id,
                "search_agent_id": search_agent.get("agent_id"),
                "generate_agent_id": generate_agent.get("agent_id")
            }
            await db.projects.update_one(
                {"_id": project_id},
                {"$set": update_data}
            )

    except Exception as e:
        print(f"Error analyzing repository: {str(e)}")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)



# Agent instructions
SEARCH_INSTRUCTIONS = """Your TASK is to ASSIST users in finding SPECIFIC code elements within their codebase. You MUST follow these STEPS:

1. **UNDERSTAND the SEARCH INTENT**: CLARIFY what the user is looking for, such as functions, classes, variables, or patterns.

2. **IDENTIFY SEARCH SCOPE**: DETERMINE the files, directories, or code components to SEARCH within.

3. **PERFORM the SEARCH**: UTILIZE appropriate search METHODS:
   - For TEXT-based SEARCH, IDENTIFY keywords or identifiers.
   - For SYNTACTIC SEARCH, IDENTIFY CODE structures and patterns.
   - For SEMANTIC SEARCH, IDENTIFY FUNCTIONALITY regardless of naming.

4. **PRESENT RESULTS CONCISELY**: FORMAT your findings with:
   - FILE paths and LINE numbers
   - CODE snippets with relevant CONTEXT
   - BRIEF explanations of HOW the code WORKS

5. **PROVIDE INSIGHTS**: OFFER observations on:
   - Code STRUCTURE
   - RELATIONSHIPS between components
   - POSSIBLE improvements or ISSUES

6. **SUGGEST NEXT STEPS**: RECOMMEND RELATED searches or areas to EXPLORE.

ENSURE that responses are CLEAR and DIRECT, with properly FORMATTED code EXAMPLES when appropriate.""" 

GENERATE_INSTRUCTIONS = """### **EXECUTION STEPS:**

1. **INTERPRET REQUIREMENTS:**  
   - UNDERSTAND the USER REQUIREMENT and the specified PROGRAMMING LANGUAGE.  
   - UTILIZE any provided RAG for CLARITY and GUIDANCE.  
   - CHECK the metadata for EXISTING CODE related to the request. If FOUND, RETRIEVE and PRESENT it instead of generating new code.  

2. **CODE RETRIEVAL & GENERATION:**  
   - IF RELEVANT CODE EXISTS in the METADATA, return it as the response.  
   - IF NO EXISTING CODE is found, PRODUCE the necessary function, class, or script that MEETS the requirements.  
   - ADHERE to best practices for MAINTAINABILITY, ensuring proper variable naming, indentation, and modularity.  
   - PRIORITIZE reusing any existing component class variables if present.  

3. **DOCUMENTATION:**  
   - ENSURE the code is WELL-DOCUMENTED with clear explanations.  
   - INCLUDE COMMENTS to guide the user through the logic and structure effectively.  

4. **CONSTRAINTS COMPLIANCE:**  
   - KEEP the code SIMPLE and avoid UNNECESSARY complexity.  
   - ENSURE it aligns with constraints and MAXIMIZES efficiency.  

5. **REVIEW & VALIDATION:**  
   - VERIFY the COMPLETENESS and CORRECTNESS of the provided code.  
   - ENSURE it meets the expected output and COMPLIES with all specified guidelines.  
   - IF the code is RETRIEVED from METADATA, CONFIRM its relevance before returning it.  """  


def create_rag_collection():
    try:
        print("Inside Create Rag Collection Function")
        response = requests.post(
            f"{LYZR_RAG_API_URL}/",
            headers={"x-api-key": API_KEY},
            json={
                "user_id": USER_ID,
                "llm_credential_id": "lyzr_openai",
                "embedding_credential_id": "lyzr_openai",
                "vector_db_credential_id": "lyzr_weaviate",
                "vector_store_provider": "Weaviate [Lyzr]",
                "description": "Repository analysis RAG",
                "collection_name": f"repo_rag_{int(time.time())}",
                "llm_model": "gpt-4o-mini",
                "embedding_model": "text-embedding-ada-002"
            }
        )
        print("Rag creating ",response.json())
        return response.json().get('id')
    except Exception as e:
        print(f"RAG creation failed: {str(e)}")
        return None
    
def train_rag(rag_id, documents):
    try:
        print("TRAIN RAG");

        # response = requests.post(
        #     f"{LYZR_RAG_API_URL}/train/{rag_id}/"
        # )
        print('document',documents);
        response = requests.post(
            f"{LYZR_RAG_API_URL}/train/{rag_id}/",
            headers={"x-api-key": API_KEY},
            json=documents
        )

        print("RESPONSE FOR TRANING ")
    
        return True
    except Exception as e:
        print(f"RAG training failed: {str(e)}")
        return False


def create_agent(rag_id, agent_type, instructions, project_name):
    try:
        url = "https://agent-prod.studio.lyzr.ai/v3/agents/template/single-task"  # Correct API URL
        headers = {
            "x-api-key": API_KEY,
            "Content-Type": "application/json"
        }
        payload = {
            "name": f"repo_{project_name}_{agent_type}_agent",
            "agent_instructions": instructions,  
            "agent_role": f"Agent for code {agent_type}",
            "llm_credential_id": "lyzr_openai",
            "provider_id": "OpenAI",
            "model": "gpt-4o-mini",
            "temperature": 0.7,
            "top_p": 0.9,
            "features": [
                {
                    "type": "KNOWLEDGE_BASE",  # Ensure this is a valid type in API docs
                    "config": {
                        "lyzr_rag": {
                            "base_url": "https://rag-prod.studio.lyzr.ai",
                            "rag_id": "67c6ba82d685a611072265cd",
                            "rag_name": "SakSoft Code Rag"
                        }
                    },
                    "priority": 0
                }
            ],
            "tools": []  # Fixed: should be an array, not `None`
        }
        
        response = requests.post(url, headers=headers, json=payload)
        print("Creating agent response:", payload, response.status_code, response.text)

        if response.status_code == 405:
            print("⚠️ Method Not Allowed: Check if POST is the correct method.")
        elif response.status_code == 403:
            print("❌ Forbidden: Check if your API key is correct.")
        
        return response.json() if response.status_code == 200 else None
    
    except Exception as e:
        print(f"⚠️ Agent creation failed: {str(e)}")
        return None


@app.post("/project/{project_id}/code/search")
async def code_search(query: AgentQuery):
    try:
        project = await db.projects.find_one(
            {"_id": ObjectId(query.project_id)},
            {"search_agent_id": 1}
        )
        if not project or "search_agent_id" not in project:
            raise HTTPException(status_code=404, detail="Agent not configured")

        payload = {
            "user_id": USER_ID,
            # "agent_id": project["search_agent_id"],
            # "session_id": project["search_agent_id"],
            "agent_id": "67c556420606a0f240481e79",
            "session_id": "67c556420606a0f240481e79",
            "message": query.message
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                LYZR_API_URL,
                json=payload,
                headers={"x-api-key": API_KEY}
            )
        return response.json()
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/project/{project_id}/code/generate")
async def code_generate(query: AgentQuery):
    try:
        project = await db.projects.find_one(
            {"_id": ObjectId(query.project_id)},
            {"generate_agent_id": 1}
        )
        if not project or "generate_agent_id" not in project:
            raise HTTPException(status_code=404, detail="Agent not configured")

        payload = {
            "user_id": USER_ID,
            # "agent_id": project["generate_agent_id"],
            # "session_id": project["generate_agent_id"],
            "agent_id": "67c55dfe8cfac3392e3a4eb0",
            "session_id": "67c55dfe8cfac3392e3a4eb0",
            "message": query.message
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                LYZR_API_URL,
                json=payload,
                headers={"x-api-key": API_KEY}
            )
        return response.json()
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
# 5️⃣ Update Project (PUT)
@app.put("/project/{project_id}")
async def update_project(project_id: str, project: ProjectCreate):
    obj_id = ObjectId(project_id)
    result = await db.projects.update_one({"_id": obj_id}, {"$set": {"name": project.name}})
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Project not found or no changes made")
    return {"message": "Project updated successfully"}

# 6️⃣ Get Project Details (GET)
@app.get("/project/{project_id}")
async def get_project(project_id: str):
    project = await db.projects.find_one({"_id": ObjectId(project_id)})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project

# 7️⃣ Delete Project (DELETE)
@app.delete("/project/{project_id}")
async def delete_project(project_id: str):
    result = await db.projects.delete_one({"_id": ObjectId(project_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"message": "Project deleted successfully"}



# # 3️⃣ Code Search Endpoint
# @app.post("/code_search")
# async def code_search(query: CodeQuery):
#     payload = {
#         "user_id": USER_ID,
#         "agent_id": "67c556420606a0f240481e79",
#         "session_id": "67c556420606a0f240481e79",
#         "message": query.message
#     }
#     async with httpx.AsyncClient(timeout=30.0) as client:
#         response = await client.post(LYZR_API_URL, json=payload, headers={"x-api-key": API_KEY})
#     if response.status_code != 200:
#         raise HTTPException(status_code=response.status_code, detail=response.text)
#     return response.json()

# # 4️⃣ Code Generation Endpoint
# @app.post("/code_generate")
# async def code_generate(query: CodeQuery):
#     payload = {
#         "user_id": USER_ID,
#         "agent_id": "67c55dfe8cfac3392e3a4eb0",
#         "session_id": "67c55dfe8cfac3392e3a4eb0",
#         "message": query.message
#     }
#     async with httpx.AsyncClient(timeout=30.0) as client:
#         response = await client.post(LYZR_API_URL, json=payload, headers={"x-api-key": API_KEY})
#     if response.status_code != 200:
#         raise HTTPException(status_code=response.status_code, detail=response.text)
#     return response.json()
