# analyzer/core.py
import os
import re
import glob
import json
import sqlparse
import shutil
import requests
from tqdm import tqdm
from pathlib import Path
from datetime import datetime
import matplotlib.pyplot as plt
from collections import Counter
from typing import List, Dict

class RepositoryAnalyzer:
    def __init__(self):
        self.api_url = "https://agent-prod.studio.lyzr.ai/v3/inference/chat/"
        self.headers = {
            "Content-Type": "application/json",
            "x-api-key": "sk-default-yStV4gbpjadbQSw4i7QhoOLRwAs5dEcl"
        }
        self.user_id = "pranav@lyzr.ai"

    def _call_lyzr_api(self, agent_id: str, session_id: str, system_prompt: str, message: str) -> str:
        """Helper function to call Lyzr API"""
        messages = json.dumps([
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": message}
        ])

        payload = {
            "user_id": self.user_id,
            "agent_id": agent_id,
            "session_id": session_id,
            "message": messages
        }

        try:
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
            )
            response.raise_for_status()
            return response.json().get("response", "")
        except requests.exceptions.RequestException as e:
            print(f"Request failed: {str(e)}")
            return json.dumps({"error": str(e)})

    def analyze_file_with_llm(self, file_path, content, file_type):
        """
        Analyze a file with an LLM to understand its purpose and extract metadata
        based on file type context.

        Args:
            file_path: Path to the file
            content: Content of the file
            file_type: Type of the file (e.g., 'py', 'js', 'sql')
            api_key: OpenAI API key
            model: Model to use for analysis (gpt-3.5-turbo or gpt-4o-mini)

        Returns:
            Dictionary with purpose, summary, and file-type specific metadata
        """
        max_chars = 12000
        if len(content) > max_chars:
            content = content[:max_chars] + "...[truncated]"

        try:
            system_prompt = "You are a code analysis assistant specialized in extracting structured metadata from code files."
            user_prompt = ""

            # Create system and user prompts based on file type
            system_prompt = "You are a code analysis assistant specialized in extracting structured metadata from code files."
            user_prompt = ""

            # Python files: Extract functions, classes, imports
            if file_type == 'py':
                system_prompt += " You analyze Python code to identify functions, classes, imports, and API endpoints."
                user_prompt = f"""Analyze this Python file and extract the following in JSON format:
                  1. purpose: A one-sentence description of the file's main purpose
                  2. summary: 2-3 sentences summarizing key functionality
                  3. metadata:
                    - functions: List of function names with their parameters
                    - classes: List of class names
                    - imports: Key libraries being imported
                    - api_endpoints: Any API endpoints defined (look for Flask, FastAPI, Django patterns)

                  Code:
                  ```python
                  {content.strip()}
                  ```"""

            # JavaScript/TypeScript: Extract functions, components, imports
            elif file_type in ['js', 'ts', 'jsx', 'tsx']:
                system_prompt += " You analyze JavaScript/TypeScript code to identify functions, components, imports, and API endpoints."
                user_prompt = f"""Analyze this {file_type.upper()} file and extract the following in JSON format:
                  1. purpose: A one-sentence description of the file's main purpose
                  2. summary: 2-3 sentences summarizing key functionality
                  3. metadata:
                    - functions: List of function/method names
                    - components: List of UI component names (for React/Vue files)
                    - imports: Key libraries being imported
                    - api_endpoints: Any API endpoints defined (look for Express, NestJS patterns)

                  Code:
                  ```javascript
                  {content.strip()}
                  ```"""

            # SQL: Extract tables, columns, relationships
            elif file_type == 'sql':
                system_prompt += " You analyze SQL schemas, Stored procedures to identify tables, columns, relationships, and constraints."
                user_prompt = f"""Analyze this SQL file and extract the following in JSON format:
                  1. purpose: A one-sentence description of the schema's purpose
                  2. summary: 2-3 sentences summarizing key tables and relationships
                  3. metadata:
                    - tables: List of table names defined in CREATE TABLE statements
                    - columns: For each table, list key columns and their data types
                    - primary_keys: List of primary key columns
                    - foreign_keys: List of foreign key relationships
                    - indexes: Any indexes defined

                  SQL:
                  ```sql
                  {content.strip()}
                  ```"""

            # HTML/UI components: Extract form elements, inputs, structure
            elif file_type in ['html', 'jsx', 'tsx', 'vue']:
                system_prompt += " You analyze UI component files to identify structure, forms, inputs, and key UI elements."
                user_prompt = f"""Analyze this UI component file and extract the following in JSON format:
                  1. purpose: A one-sentence description of the component's purpose
                  2. summary: 2-3 sentences summarizing key UI features
                  3. metadata:
                    - forms: Number and purpose of any forms
                    - inputs: Types of input elements (text, select, button, etc.)
                    - tables: Description of any data tables
                    - components: Child components used
                    - state_variables: Any state variables (for React/Vue)

                  Code:
                  ```html
                  {content.strip()}
                  ```"""

            # Java files: Extract classes, methods, annotations
            elif file_type == 'java':
                system_prompt += " You analyze Java code to identify classes, methods, annotations, and API endpoints."
                user_prompt = f"""Analyze this Java file and extract the following in JSON format:
                  1. purpose: A one-sentence description of the file's main purpose
                  2. summary: 2-3 sentences summarizing key functionality
                  3. metadata:
                    - classes: List of class names
                    - methods: List of method names with return types
                    - annotations: Key annotations (@RequestMapping, etc.)
                    - api_endpoints: Any API endpoints defined (look for Spring patterns)

                  Code:
                  ```java
                  {content.strip()}
                  ```"""

            # PHP files: Extract functions, classes, routes
            elif file_type == 'php':
                system_prompt += " You analyze PHP code to identify functions, business logic summary, classes, and routing patterns, key topics."
                user_prompt = f"""Analyze this PHP file and extract the following in JSON format:
                  1. purpose: A one-sentence description of the file's main purpose
                  2. summary: 2-3 sentences summarizing key functionality
                  3. metadata:
                    - functions: List of function names
                    - classes: List of class names
                    - routes: Any route definitions (Laravel, Symfony patterns)
                    - dependencies: Key dependencies or imports

                  Code:
                  ```php
                  {content.strip()}
                  ```"""

                          # Default for other file types
            else:
              user_prompt = f"""Analyze this file and extract the following in JSON format:
                1. purpose: A one-sentence description of the file's main purpose
                2. summary: 2-3 sentences summarizing key functionality
                3. metadata: Any structured information you can extract from this {file_type} file

                Content:
                ```
                {content.strip()}
                ```"""

        # Request analysis
        # response = client.chat.completions.create(
        #     model=model,
        #     messages=[
        #         {"role": "system", "content": system_prompt},
        #         {"role": "user", "content": user_prompt}
        #     ],
        #     response_format={"type": "json_object"},
        #     max_tokens=1000,
        #     temperature=0.2
        # )

        # analysis = response.choices[0].message.content.strip()

            # Other file type handlers (JavaScript, SQL, etc.)
            # ... (preserve all original conditional blocks)

            analysis = self._call_lyzr_api(
                agent_id="67c0a7d20606a0f24048043d",
                session_id="67c0a7d20606a0f24048043d",
                system_prompt=system_prompt,
                message=user_prompt
            )

            analysis = analysis.replace('```json', '').replace('```', '')
            return json.loads(analysis)

        except Exception as e:
            print(f"Error analyzing file {file_path}: {e}")
            return {
                "purpose": f"Error analyzing file: {str(e)[:100]}",
                "summary": "",
                "metadata": {}
            }

    def extract_db_metadata(self, repo_dir):
        """Extract database schemas from various file types"""
        db_files = []
        extensions = ['sql', 'py', 'java', 'cs', 'php', 'rb', 'go', 'ts', 'rs', 'kt', 'swift']
        for ext in extensions:
            db_files.extend(glob.glob(f"{repo_dir}/**/*.{ext}", recursive=True))

        db_schemas = []
        DB_SYSTEM_PROMPT = """You are a database schema analysis expert. Extract:
          - Tables with columns, data types, constraints
          - Primary/foreign keys
          - Indexes
          - Relationships between tables
          - ORM model definitions

          Return in this JSON format:
          {
              "tables": [{
                  "name": "users",
                  "columns": [
                      {
                          "name": "id",
                          "type": "integer",
                          "primary_key": true,
                          "foreign_key": {
                              "references_table": null,
                              "references_column": null
                          }
                      }
                  ],
                  "primary_keys": ["id"],
                  "indexes": [],
                  "purpose": "Stores user information"
              }],
              "database_purpose": "Core application database",
              "database_summary": "Contains user, product, and order data"
          }"""  # Keep original prompt

        for file_path in tqdm(db_files):
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                if len(content) > 100000 or len(content) < 10:
                    continue

                ext = os.path.splitext(file_path)[1][1:]
                user_prompt = f"""Analyze this {ext} file and extract database schema information.
                Convert ORM models/definitions to database tables and relationships.
                Include all data types, constraints, and indexes.
                
                File Content:
                ```{ext}
                {content.strip()}
                ```
                """ 

                analysis = self._call_lyzr_api(
                    agent_id="67c0a8b08cfac3392e3a3522",
                    session_id="67c0a8b08cfac3392e3a3522",
                    system_prompt=DB_SYSTEM_PROMPT,
                    message=user_prompt
                )

                try:
                    schema_data = json.loads(analysis.replace('```json', '').replace('```', ''))
                    tables = schema_data.get("tables", [])
                    
                    for table_info in tables:
                        # Process columns
                        columns = []
                        for col in table_info.get("columns", []):
                            column_data = {
                                "name": col.get("name", ""),
                                "type": col.get("type", "unknown"),
                                "nullable": col.get("nullable", True),
                                "primary_key": col.get("primary_key", False),
                                "foreign_key": col.get("foreign_key", None)
                            }
                            columns.append(column_data)

                        # Create standardized schema entry
                        schema = {
                            "type": "database_schema",
                            "table_name": table_info.get("name", "unknown"),
                            "columns": columns,
                            "column_count": len(columns),
                            "purpose": table_info.get("purpose", ""),
                            "summary": schema_data.get("database_summary", ""),
                            "file_path": os.path.relpath(file_path, repo_dir),
                            "file_name": os.path.basename(file_path),
                            "primary_keys": table_info.get("primary_keys", []),
                            "indexes": table_info.get("indexes", []),
                            "metadata": {
                                "database_purpose": schema_data.get("database_purpose", ""),
                                "orm_framework": self.detect_orm_framework(content),
                                "relationships": self.detect_table_relationships(content),
                                "constraints": self.extract_constraints(columns)
                            }
                        }
                        db_schemas.append(schema)

                except json.JSONDecodeError:
                    print(f"Failed to parse schema response for {file_path}")
                    continue
                
            except Exception as e:
                print(f"Error processing {file_path}: {e}")

        return db_schemas
    
    def detect_orm_framework(self, content):
      """Detect ORM frameworks from code patterns"""
      patterns = {
          "django": r"from django\.db import models|class \w+\(models\.Model\)",
          "sqlalchemy": r"from sqlalchemy import Column|class \w+\(Base\)",
          "sequelize": r"const \w+ = sequelize\.define|Sequelize\.\w+",
          "hibernate": r"@Entity|@Table\(name =",
          "active_record": r"class \w+ < ApplicationRecord",
          "typeorm": r"@Entity\(\)|export class \w+ implements EntitySchema",
          "ef_core": r"public class \w+ : DbContext|modelBuilder\.Entity<"
      }
      
      for framework, pattern in patterns.items():
          if re.search(pattern, content, re.IGNORECASE):
              return framework
      return "unknown"

    def detect_table_relationships(self, content):
        """Detect common table relationships"""
        relationships = []
        if re.search(r"ForeignKey|@OneToMany|@ManyToOne|has_many|belongs_to", content):
            relationships.append("one-to-many")
        if re.search(r"@ManyToMany|many_to_many|has_and_belongs_to_many", content):
            relationships.append("many-to-many")
        if re.search(r"@OneToOne|has_one", content):
            relationships.append("one-to-one")
        return relationships if relationships else ["unknown"]

    def extract_constraints(self, columns):
        """Extract constraints from column data"""
        constraints = {
            "primary_keys": [],
            "foreign_keys": [],
            "unique": [],
            "indexes": []
        }
        
        for col in columns:
            if col.get("primary_key"):
                constraints["primary_keys"].append(col["name"])
            if col.get("foreign_key"):
                constraints["foreign_keys"].append({
                    "column": col["name"],
                    "references": col["foreign_key"]
                })
            if col.get("unique"):
                constraints["unique"].append(col["name"])
                
        return constraints


    def extract_api_metadata(self, repo_dir):
        """Extract API endpoints from various file types"""
        api_files = []
        extensions = ['py', 'js', 'ts', 'java', 'go', 'php', 'rb', 'jsx', 'tsx', 'cs', 'swift', 'kt', 'rs', 'dart', 'json', 'yaml']
        for ext in extensions:
            api_files.extend(glob.glob(f"{repo_dir}/**/*.{ext}", recursive=True))

        api_metadata = []
        API_SYSTEM_PROMPT = """You are an API analysis expert. Extract API endpoints with:
        - method: HTTP method (GET, POST, etc.)
        - route: Full endpoint path
        - parameters: List of path/query parameters
        - description: Brief functionality description
        - request_body: JSON schema if available
        - response_format: Expected response format
        - security: Authentication methods used

        Return endpoints in this JSON format:
        {
            "api_endpoints": [{
                "method": "GET",
                "route": "/api/v1/users",
                "parameters": ["id"],
                "description": "Get user details",
                "request_body": null,
                "response_format": "application/json",
                "security": ["JWT"]
            }]
        }"""  # Keep original prompt

        for file_path in tqdm(api_files):
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                if len(content) > 100000 or len(content) < 10:
                    continue

                user_prompt = f"""Analyze this {os.path.splitext(file_path)[1]} file and extract all API endpoints.
                Include both REST and GraphQL endpoints. Preserve exact route paths and parameters.
                
                File Content:
                ```{os.path.splitext(file_path)[1][1:]}
                {content.strip()}
                ```
                """  

                analysis = self._call_lyzr_api(
                    agent_id="67c1a9818cfac3392e3a3da9",
                    session_id="67c1a9818cfac3392e3a3da9",
                    system_prompt=API_SYSTEM_PROMPT,
                    message=user_prompt
                )

                try:
                    endpoint_data = json.loads(analysis.replace('```json', '').replace('```', ''))
                    print("endpoint_data", endpoint_data, analysis)
                    endpoints = endpoint_data.get("api_endpoints", [])
                    
                    if endpoints:
                        # Create standardized metadata entry
                        api_entry = {
                            "type": "api_endpoint",
                            "file_path": os.path.relpath(file_path, repo_dir),
                            "file_name": os.path.basename(file_path),
                            "language": os.path.splitext(file_path)[1][1:],
                            "endpoints": [],
                            "framework": self.detect_api_framework(content),
                            "metadata": {
                                "security_schemes": list(set(
                                    ep["security"][0] 
                                    for ep in endpoints 
                                    if ep.get("security")
                                )),
                                "methods_used": list(set(ep["method"] for ep in endpoints))
                            }
                        }

                        # Add endpoint details
                        for ep in endpoints:
                            api_entry["endpoints"].append({
                                "method": ep.get("method", "UNKNOWN"),
                                "route": ep.get("route", ""),
                                "parameters": ep.get("parameters", []),
                                "description": ep.get("description", ""),
                                "request_schema": ep.get("request_body"),
                                "response_format": ep.get("response_format"),
                                "security": ep.get("security", [])
                            })

                        api_metadata.append(api_entry)

                except json.JSONDecodeError:
                    print(f"Failed to parse API response for {file_path}")
                    continue


            except Exception as e:
                print(f"Error processing {file_path}: {e}")

        return api_metadata
    
    def detect_api_framework(self, content):
        """Enhanced framework detection with common patterns"""
        patterns = {
            "flask": r"@app\.route|from flask(?!\w)",
            "express": r"app\.(get|post)|require\(['\"]express",
            "spring": r"@(RestController|GetMapping|PostMapping)",
            "django": r"@api_view|from rest_framework",
            "fastapi": r"@app\.(get|post)|from fastapi",
            "graphql": r"type (Query|Mutation)|@(Query|Mutation)",
            "grpc": r"service \w+ {|rpc \w+",
            "aws_lambda": r"@lambda_handler|aws_lambda",
            "google_cloud": r"@functions_framework|google.cloud"
        }
        
        for framework, pattern in patterns.items():
            if re.search(pattern, content, re.IGNORECASE):
                return framework
        return "unknown"


    def extract_ui_metadata(self, repo_dir):
        """Extract UI component metadata"""
        ui_files = []
        extensions = ['html', 'htm', 'jsx', 'tsx', 'vue']
        for ext in extensions:
            ui_files.extend(glob.glob(f"{repo_dir}/**/*.{ext}", recursive=True))

        ui_metadata = []
        for file_path in tqdm(ui_files):
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                if len(content) > 50000 or len(content) < 10:
                    continue

                file_ext = os.path.splitext(file_path)[1][1:].lower()
                analysis = self.analyze_file_with_llm(file_path, content, file_ext)
                
                # Create UI metadata entry
                ui_entry = {
                    "type": "ui_component",
                    "file_path": os.path.relpath(file_path, repo_dir),
                    "file_name": os.path.basename(file_path),
                    "purpose": analysis.get('purpose', ''),
                    "summary": analysis.get('summary', ''),
                    "ui_type": file_ext,
                    "metadata": {
                        "forms": analysis.get('metadata', {}).get('forms', 0),
                        "inputs": analysis.get('metadata', {}).get('inputs', []),
                        "components": analysis.get('metadata', {}).get('components', []),
                        "tables": analysis.get('metadata', {}).get('tables', []),
                        "state_variables": analysis.get('metadata', {}).get('state_variables', [])
                    }
                }

                ui_metadata.append(ui_entry)

            except Exception as e:
                print(f"Error processing {file_path}: {e}")

        return ui_metadata
    
    def extract_rag_metadata(self, repo_dir: str) -> List[Dict]:
        """Extract RAG metadata for all files in the repository"""
        all_files = []
        for root, dirs, files in os.walk(repo_dir):
            for file in files:
                if file.startswith('.'):
                    continue  # Skip hidden files
                file_path = os.path.join(root, file)
                all_files.append(file_path)

        rag_metadata = []
        
        for file_path in tqdm(all_files, desc="Processing RAG Metadata"):
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                # Skip binary files and large files
                if len(content) > 100000 or '\x00' in content:
                    continue

                # Call RAG metadata agent
                rag_response = self._call_lyzr_api(
                    agent_id="67c48f268cfac3392e3a48e2",
                    session_id="67c48f268cfac3392e3a48e2",
                    system_prompt="",  # Empty since RAG agent doesn't need system prompt
                    message=json.dumps({
                        "file_path": os.path.relpath(file_path, repo_dir),
                        "content": content[:15000]  # Truncate to 15k characters
                    })
                )
                parsed_response = json.loads(rag_response.replace('```json', '').replace('```', ''))
            
                rag_metadata.append({
                    "file_path": os.path.relpath(file_path, repo_dir),
                    "file_name": os.path.basename(file_path),
                    "file_type": os.path.splitext(file_path)[1][1:].lower(),
                    "rag_metadata": parsed_response,
                    "analysis_date": datetime.now().isoformat()
                })
                # endpoints = endpoint_data.get("api_endpoints", [])

            except Exception as e:
                print(f"Error processing RAG metadata for {file_path}: {e}")

        return rag_metadata


    def visualize_results(self, db_schemas, api_data, ui_data, output_dir):
        """Generate analysis visualizations"""
        viz_data = {}
        viz_dir = os.path.join(output_dir, "visualizations")
        os.makedirs(viz_dir, exist_ok=True)

        try:
            # 1. File type distribution pie chart
            file_counts = {
                "Database Files": len(db_schemas),
                "API Files": len(api_data),
                "UI Components": len(ui_data)
            }
            plt.figure(figsize=(10, 6))
            plt.pie(file_counts.values(), labels=file_counts.keys(), autopct='%1.1f%%', startangle=90)
            plt.axis('equal')
            plt.title('Repository File Type Distribution')
            file_dist_path = os.path.join(viz_dir, "file_distribution.png")
            plt.savefig(file_dist_path)
            plt.close()
            viz_data['file_distribution'] = file_dist_path

            # 2. API methods/endpoints bar chart
            if api_data:
                api_methods_count = []
                for api in api_data:
                    if "api_methods" in api:
                        api_methods_count.append(len(api.get("api_methods", [])))
                    elif "endpoints" in api:
                        api_methods_count.append(len(api.get("endpoints", [])))
                    else:
                        api_methods_count.append(0)

                plt.figure(figsize=(12, 6))
                plt.hist(api_methods_count, bins=10, alpha=0.7, color='blue')
                plt.xlabel('Number of API Methods/Endpoints per File')
                plt.ylabel('Number of Files')
                plt.title('Distribution of API Methods/Endpoints')
                plt.grid(True, alpha=0.3)
                api_methods_path = os.path.join(viz_dir, "api_methods_distribution.png")
                plt.savefig(api_methods_path)
                plt.close()
                viz_data['api_methods_distribution'] = api_methods_path

            # 3. Framework usage bar chart
            if api_data:
                frameworks = [api.get("metadata", {}).get("framework", "unknown") for api in api_data]
                framework_counter = Counter(frameworks)

                plt.figure(figsize=(10, 6))
                plt.bar(framework_counter.keys(), framework_counter.values())
                plt.xlabel('Framework')
                plt.ylabel('Number of Files')
                plt.title('API Framework Usage')
                plt.xticks(rotation=45)
                plt.tight_layout()
                framework_usage_path = os.path.join(viz_dir, "framework_usage.png")
                plt.savefig(framework_usage_path)
                plt.close()
                viz_data['framework_usage'] = framework_usage_path

        except Exception as e:
            print(f"Visualization error: {str(e)}")

        return viz_data

    def create_html_summary(self, db_schemas, api_data, ui_data, rag_data,viz_dir, output_dir):
        """
        Create an HTML summary report of the repository analysis

        Args:
            db_schemas: Database schema metadata
            api_data: API metadata
            ui_data: UI component metadata
            viz_dir: Directory with visualizations
            output_dir: Output directory
        """
        html_content = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Repository Analysis Summary</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }}
                h1, h2, h3 {{ color: #2c3e50; }}
                .container {{ max-width: 1200px; margin: 0 auto; }}
                .summary-box {{ background-color: #f8f9fa; border-radius: 5px; padding: 15px; margin-bottom: 20px; }}
                .visualization {{ margin: 30px 0; text-align: center; }}
                table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
                th, td {{ padding: 12px 15px; text-align: left; border-bottom: 1px solid #ddd; }}
                th {{ background-color: #f2f2f2; }}
                tr:hover {{ background-color: #f5f5f5; }}
                .file-path {{ font-family: monospace; color: #666; font-size: 0.9em; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Repository Analysis Summary</h1>

                <div class="summary-box">
                    <h2>Overview</h2>
                    <p>Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
                    <p>Total Files Analyzed: {len(db_schemas) + len(api_data) + len(ui_data)}</p>
                    <ul>
                        <li>Database Schemas: {len(db_schemas)}</li>
                        <li>API Files: {len(api_data)}</li>
                        <li>UI Components: {len(ui_data)}</li>
                    </ul>
                </div>

                <div class="visualization">
                    <h2>Visualizations</h2>
                    <img src="visualizations/file_distribution.png" alt="File Distribution" style="max-width: 100%;">
        """

        # Add API visualization if available
        if api_data and os.path.exists(os.path.join(viz_dir, "api_methods_distribution.png")):
            html_content += f"""
                    <img src="visualizations/api_methods_distribution.png" alt="API Methods Distribution" style="max-width: 100%;">
                    <img src="visualizations/framework_usage.png" alt="Framework Usage" style="max-width: 100%;">
            """

        # API Section
        if api_data:
            html_content += """
                <h2>API Files</h2>
                <table>
                    <tr>
                        <th>File Name</th>
                        <th>Purpose</th>
                        <th>API Type</th>
                        <th>Endpoints/Methods</th>
                    </tr>
            """

            for api in api_data:
                endpoint_count = len(api.get("endpoints", [])) if "endpoints" in api else len(api.get("api_methods", []))
                api_type = "REST Endpoint" if "endpoints" in api else "API Client"

                html_content += f"""
                    <tr>
                        <td>{api.get("file_name", "")}</td>
                        <td>{api.get("purpose", "")}</td>
                        <td>{api_type}</td>
                        <td>{endpoint_count}</td>
                    </tr>
                """

            html_content += "</table>"

        # Database Section
        if db_schemas:
            html_content += """
                <h2>Database Schemas</h2>
                <table>
                    <tr>
                        <th>Table Name</th>
                        <th>Purpose</th>
                        <th>Columns</th>
                        <th>File Path</th>
                    </tr>
            """

            for schema in db_schemas:
                if schema.get("type") == "database_schema":
                    html_content += f"""
                        <tr>
                            <td>{schema.get("table_name", "")}</td>
                            <td>{schema.get("purpose", "")}</td>
                            <td>{schema.get("column_count", 0)}</td>
                            <td class="file-path">{schema.get("file_path", "")}</td>
                        </tr>
                    """

            html_content += "</table>"

        # UI Components Section
        if ui_data:
            html_content += """
                <h2>UI Components</h2>
                <table>
                    <tr>
                        <th>File Name</th>
                        <th>Purpose</th>
                        <th>Type</th>
                        <th>Forms</th>
                        <th>Inputs</th>
                    </tr>
            """

            for ui in ui_data:
                input_count = len(ui.get("metadata", {}).get("inputs", []))
                forms_count = ui.get("metadata", {}).get("forms", 0)

                html_content += f"""
                    <tr>
                        <td>{ui.get("file_name", "")}</td>
                        <td>{ui.get("purpose", "")}</td>
                        <td>{ui.get("ui_type", "")}</td>
                        <td>{forms_count}</td>
                        <td>{input_count}</td>
                    </tr>
                """

            html_content += "</table>"
        if rag_data:
            html_content += """
                <h2>RAG Metadata Overview</h2>
                <table>
                    <tr>
                        <th>File Name</th>
                        <th>File Type</th>
                        <th>Key Entities</th>
                        <th>Key Concepts</th>
                    </tr>
            """

            for rag_entry in rag_data[:100]:  # Show first 100 entries
                metadata = rag_entry.get('rag_metadata', {})
                html_content += f"""
                    <tr>
                        <td>{rag_entry.get("file_name", "")}</td>
                        <td>{rag_entry.get("file_type", "")}</td>
                        <td>{', '.join(metadata.get('key_entities', []))[:50]}...</td>
                        <td>{', '.join(metadata.get('key_concepts', []))[:50]}...</td>
                    </tr>
                """

            html_content += "</table>"

        # Close HTML
        html_content += """
            </div>
        </body>
        </html>
        """

        # Write HTML file
        with open(os.path.join(output_dir, "analysis_report.html"), "w") as f:
            f.write(html_content)

        print(f"HTML report created: {os.path.join(output_dir, 'analysis_report.html')}")

    # def detect_orm_framework(self, content):
    #     """Detect ORM frameworks from code patterns"""
    #     patterns = {
    #         "django": r"from django\.db import models|class \w+\(models\.Model\)",
    #         # ... other patterns
    #     }
    #     for framework, pattern in patterns.items():
    #         if re.search(pattern, content, re.IGNORECASE):
    #             return framework
    #     return "unknown"

    # def detect_table_relationships(self, content):
    #     """Detect common table relationships"""
    #     relationships = []
    #     # ... (preserve original detection logic)
    #     return relationships

    # def extract_constraints(self, columns):
    #     """Extract constraints from column data"""
    #     constraints = {
    #         "primary_keys": [],
    #         "foreign_keys": [],
    #         "unique": [],
    #         "indexes": []
    #     }
    #     # ... (preserve original logic)
    #     return constraints

    # def detect_api_framework(self, content):
    #     """Detect API frameworks from code patterns"""
    #     patterns = {
    #         "flask": r"@app\.route|from flask(?!\w)",
    #         # ... other patterns
    #     }
    #     for framework, pattern in patterns.items():
    #         if re.search(pattern, content, re.IGNORECASE):
    #             return framework
    #     return "unknown"

    def analyze_repository(self, repo_dir):
        """Main analysis entry point"""
        print("Analyzing repository...")
        output_base = os.path.join(os.getcwd(), "out")
        os.makedirs(output_base, exist_ok=True)

        repo_name = os.path.basename("Repo")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = os.path.join(output_base, f"{repo_name}_{timestamp}")
        os.makedirs(output_dir, exist_ok=True)

        # Extract metadata
        db_schemas = self.extract_db_metadata(repo_dir)
        api_data = self.extract_api_metadata(repo_dir)
        ui_data = self.extract_ui_metadata(repo_dir)
        rag_data = self.extract_rag_metadata(repo_dir)

        # Generate visualizations
        viz_paths = self.visualize_results(db_schemas, api_data, ui_data, output_dir)

        # Save results
        with open(os.path.join(output_dir, "db_schemas.json"), "w") as f:
            json.dump(db_schemas, f, indent=2)
        
        with open(os.path.join(output_dir, "api_metadata.json"), "w") as f:
            json.dump(api_data, f, indent=2)
        
        with open(os.path.join(output_dir, "ui_metadata.json"), "w") as f:
            json.dump(ui_data, f, indent=2)
        
        with open(os.path.join(output_dir, "rag_metadata.json"), "w") as f:
            json.dump(rag_data, f, indent=2)
        
        # Save other files and generate HTML
        self.create_html_summary(db_schemas, api_data, ui_data, rag_data,
                               os.path.join(output_dir, "visualizations"), 
                               output_dir)

        return {
            "db_schemas": db_schemas,
            "api_data": api_data,
            "ui_data": ui_data,
            "rag_data": rag_data,
            "summary": {
                "repository": repo_dir,
                "analysis_date": str(datetime.now()),
                "file_counts": {
                    "database_schemas": len(db_schemas),
                    "api_files": len(api_data),
                    "ui_components": len(ui_data),
                    "total_files": len(rag_data)
                }
            },
            "output_dir": output_dir,
            "visualizations": viz_paths
        }